package com.mphasis.demo.bo;

import java.util.List;

import com.mphasis.demo.entities.Trainer;

public interface TrainerBo {
	public List<Trainer> getTrainer();
	  public void insertTrainer(Trainer Trainer);
	  public void updateTrainer(Trainer Trainer);
	  public void deleteTrainer(long id);
	  public Trainer getTrainerbyId(long id);
}
