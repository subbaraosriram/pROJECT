package com.mphasis.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.demo.bo.TrainerBo;
import com.mphasis.demo.entities.Trainer;

@RestController
@RequestMapping("/trainer")
public class TrainerController {
	@Autowired
	  TrainerBo trainerBo;
	@RequestMapping(value="/Trainers",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	  public  List<Trainer> getAllT()
	  {
		return trainerBo.getTrainer();
	  }
	  @RequestMapping(value="/addt",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	  public   void adds(@RequestBody Trainer trainer)
	  {
		
		  trainerBo.insertTrainer(trainer);
		  
	  } 
	  @RequestMapping(value="/updt",method=RequestMethod.PUT,produces=MediaType.APPLICATION_JSON_VALUE)
	  public    void  upd(@RequestBody Trainer trainer)
	  {
		 Trainer tar = trainerBo.getTrainerbyId(trainer.getTid());
		if(tar!=null)
		{
			
			trainerBo.updateTrainer(tar);
		}
		else
		{
			trainerBo.insertTrainer(trainer);
		}
		   
		  
	  }
	@RequestMapping(value="/delt/{id}",method=RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
	  public   void del(@PathVariable("id") long id)
	  {
		
		trainerBo.deleteTrainer(id);
		  
	  } 
	@RequestMapping(value="/get/{id}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public   Trainer get(@PathVariable("id") long id)
	{
		
		return trainerBo.getTrainerbyId(id);	  
	} 
}
