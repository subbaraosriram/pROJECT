package com.mphasis.demo.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Trainer implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private long tid;
    @Column(nullable=false,length=25)
    private String name;
   @Column(nullable=false)
    private String subject;
//   @ManyToMany(mappedBy="trainer")
//   @JsonIgnore
//   private List<Student> student;
@Override
public String toString() {
	return "Trainer [tid=" + tid + ", name=" + name + ", subject=" + subject + "]";
}
public long getTid() {
	return tid;
}
public void setTid(long tid) {
	this.tid = tid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getSubject() {
	return subject;
}
public void setSubject(String subject) {
	this.subject = subject;
}
}
