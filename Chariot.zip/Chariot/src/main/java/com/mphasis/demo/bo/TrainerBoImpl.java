package com.mphasis.demo.bo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.demo.dao.TrainerDao;
import com.mphasis.demo.entities.Trainer;
import com.mphasis.demo.exception.BuissnessException;
@Service
public class TrainerBoImpl implements TrainerBo {
	@Autowired
	TrainerDao trainerDao;
	public List<Trainer> getTrainer() {
		List<Trainer> Trainers = trainerDao.getTrainer();
		if(Trainers.isEmpty())
		{
			/*try 
			{
			  throw new Exception("no Trainers");	
			}
			catch(Exception e)
			{
			  	e.printStackTrace();
			}*/
			throw new BuissnessException("no Trainers");
		}
		return Trainers;
	}

	public void insertTrainer(Trainer Trainer) {
		trainerDao.insertTrainer(Trainer);

	}

	public void updateTrainer(Trainer Trainer) {
		trainerDao.updateTrainer(Trainer);

	}

	public void deleteTrainer(long id) {
		trainerDao.deleteTrainer(id);

	}

	public Trainer getTrainerbyId(long id) {
		// TODO Auto-generated method stub
		return trainerDao.getTrainerbyId(id);
	}

}
