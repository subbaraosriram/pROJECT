package com.mphasis.demo.exception;

public class BuissnessException extends RuntimeException 
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BuissnessException(String message)
    {
    	super(message);
    }
}
