package com.mphasis.demo.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mphasis.demo.entities.Trainer;
@Repository
public class TrainerDaoImpl implements TrainerDao {
	@Autowired 
	SessionFactory sessionFactory;

	public List<Trainer> getTrainer() {
		Session  session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction(); 
		List<Trainer> trainers = session.createCriteria(Trainer.class).list();
		tr.commit();
   	    session.close();
		return trainers;
	}

	public void insertTrainer(Trainer trainer)
	{
		Session  session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction(); 
		session.save(trainer);
		tr.commit();
   	    session.close(); 

	}

	public void updateTrainer(Trainer trainer) {
		 
		Session  session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		session.update(trainer);
		tr.commit();
		session.close();
	}

	public void deleteTrainer(long id) {
		Session  session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		Trainer trainerid = (Trainer)session.get(Trainer.class,id);
		session.delete(trainerid);
		tr.commit();
		session.close();

	}

	public Trainer getTrainerbyId(long id) {
		Session  session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		Trainer trainerid = (Trainer)session.get(Trainer.class,id);
		tr.commit();
		session.close();
	    return trainerid;
	}

}
