package com.mphasis.demo.dao;

import java.util.List;

import com.mphasis.demo.entities.Trainer;

public interface TrainerDao {
	public List<Trainer> getTrainer();
	  public void insertTrainer(Trainer Trainer);
	  public void updateTrainer(Trainer Trainer);
	  public void deleteTrainer(long id);
	  public Trainer getTrainerbyId(long id);
}
